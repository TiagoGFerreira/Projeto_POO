﻿/*
 * Ficheiro principal do trabalho de POO
 * Tiago
 * a26005@alunos.ipca.pt
 * 06-11-2023
 * POO-LESI
 */

using Regras;
using System;

namespace GerirHospital
{
    public class Program
    {
        static void Main(string[] args)
        {
            RegrasHospital.InserirPessoa("Tiago", new DateTime(2004, 08, 19), "Masculino");
        }
    }
}