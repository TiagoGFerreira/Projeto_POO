﻿
using Objetos;
using Dados;
using System;

namespace Regras
{
    public class RegrasHospital
    {
        public static bool InserirPessoa(string Nome, DateTime Nascimento, string Sexo)
        {
            if(Nascimento > DateTime.Now)
            {
                Pessoa pessoa = new Pessoa(Nome, Nascimento, Sexo);
                Pessoas.AdicionarPessoa(pessoa);
                return true;    
            }
            return false;
        }
    }
}
